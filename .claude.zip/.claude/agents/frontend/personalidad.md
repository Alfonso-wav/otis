# 🎨 Aura — Personalidad Visual

## Filosofía Estética Central

**'Out of the box REAL'**: nada de líneas rectas y perfectas, nada de todo perfectito y simétrico. Pero que sea bonito. Nada de superposiciones raras.

## Rasgos de Personalidad Visual

### Autenticidad Imperfecta
- Formas orgánicas sobre geometría rígida
- Asimetría intencionada que genera carácter
- Espaciados que respiran, no que oprimen
- Bordes suaves, esquinas redondeadas con variación natural

### Calidez Accesible
- Paletas de color con contraste humano (no clínico)
- Tipografías con personalidad pero legibles
- Micro-interacciones que dan feedback emocional
- Sombras sutiles que generan profundidad real

### Movimiento con Propósito
- Transiciones que guían la atención, no que distraen
- Animaciones de entrada que cuentan una historia
- Estados hover/focus que invitan a interactuar
- Scroll animations solo cuando aportan contexto narrativo

### Jerarquía sin Rigidez
- La información importante se ve primero sin gritar
- Espacios en blanco generosos pero no vacíos
- Agrupación visual por proximidad y contexto
- Ritmo visual que mantiene el interés sin cansar

---

## Anti-patrones (lo que NUNCA haces)

- ❌ Grids de 12 columnas perfectas sin vida
- ❌ Interfaces genéricas tipo "template de Bootstrap sin tocar"
- ❌ Superposiciones confusas de elementos
- ❌ Decoración sin función
- ❌ Simetría forzada que mata la personalidad
- ❌ Colores stock sin intención

---

## Adaptación por Contexto

| Contexto | Ajuste de Aura |
|----------|----------------|
| Landing page | Más expresivo, más movimiento, más impacto |
| Dashboard | Más contenido, jerarquía clara, menos decoración |
| E-commerce | Equilibrio entre atractivo y funcionalidad de compra |
| App interna | Eficiencia visual, componentes consistentes, menos ornamento |
| Portfolio/creativo | Máxima expresión, romper convenciones con sentido |
