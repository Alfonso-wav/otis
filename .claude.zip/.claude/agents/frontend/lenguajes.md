# ⚙️ Specs — Stack Técnico

## Stack Principal

| Capa | Tecnología | Rol |
|------|-----------|-----|
| **Lenguaje** | TypeScript | Tipado estricto, código predecible y mantenible |
| **UI Framework** | Bootstrap | Sistema de componentes base + grid responsive |
| **Visualización** | Apache ECharts | Gráficas interactivas, dashboards, data-viz |
| **Viz Avanzada** | D3.js | Control total sobre transiciones, interpolaciones y bindings de datos |
| **Motor de Animación** | GSAP | Timelines con scrubbing, morph de SVG paths, stagger de elementos |
| **Motion UI** | Framer Motion | Animaciones spring/physics en componentes React, layout morphing |
| **Timeline Visual** | Theatre.js | Secuenciador visual con GUI para diseñar animaciones complejas con scrubber |

---

## Convenciones de Código

### TypeScript
- Strict mode siempre activado
- Interfaces sobre types cuando representan contratos
- Enums para estados y opciones fijas
- Genéricos cuando aporten reutilización real
- Nunca `any` — usa `unknown` + type guards si es necesario

### Bootstrap
- Usa las utilidades de Bootstrap como base, **nunca como producto final**
- Personaliza variables SCSS para inyectar la aura visual
- Componentes custom que extienden Bootstrap, no que lo envuelven
- Breakpoints responsive: mobile-first siempre

### Apache ECharts
- Configuraciones tipadas con interfaces TypeScript
- Temas personalizados que respeten la aura del proyecto
- Lazy loading de gráficas fuera del viewport
- Tooltips informativos y accesibles
- Usa `animationDuration`, `animationEasing` y `animationDelay` para transiciones fluidas al cambiar datos

### D3.js
- `.transition().duration().ease()` para interpolar valores, colores, paths y arcos
- Bindea datos con `.data().join()` y anima enter/update/exit por separado
- Usa escalas D3 como fuente de verdad para posicionar elementos animados
- Combina con GSAP o Framer Motion para animaciones más complejas

### GSAP (GreenSock)
- `gsap.timeline()` como columna vertebral — permite scrubbing con un slider de tiempo
- `ScrollTrigger` para animaciones vinculadas al scroll
- `MorphSVGPlugin` para transiciones fluidas entre formas de gráficas
- `gsap.utils.interpolate()` para interpolar datasets en tiempo real
- Stagger (`stagger: 0.05`) para cascadas visuales en barras, puntos y líneas

### Framer Motion
- `useMotionValue` + `useTransform` para vincular sliders a propiedades animadas
- `AnimatePresence` para entrada/salida elegante de elementos de datos
- `layout` prop para morph automático cuando cambia la disposición de la gráfica
- Spring physics por defecto — los datos se sienten vivos, no robotizados

### Theatre.js
- Editor visual de timeline: diseña secuencias complejas con GUI de arrastrar
- `sequence.position` bindeable a sliders para scrubbing manual
- Ideal para narrativas de datos ("scrollytelling") y presentaciones animadas
- Exporta animaciones reproducibles sin el editor en producción

---

## Patrones de Animación de Datos

### Slider de Tiempo → Datos Animados
```
[Slider value] → [Interpolar dataset] → [Transición suave al nuevo estado]
```
- El slider controla `gsap.timeline().progress(value)` o `sequence.position` de Theatre.js
- Los datos intermedios se interpolan con D3 (`d3.interpolate`) o GSAP (`gsap.utils.interpolate`)
- ECharts recibe `setOption()` con `notMerge: false` para transiciones fluidas

### Cambio de Variables → Morph Visual
```
[Variable cambia] → [Recalcular layout] → [Animar diferencias con spring/ease]
```
- Framer Motion con `layout` hace morph automático
- GSAP con `.to()` interpola propiedades CSS/SVG directamente
- D3 con `.transition()` interpola paths, posiciones y colores

### Scroll → Narrativa de Datos
```
[Posición de scroll] → [Trigger paso N] → [Ejecutar transición de datos]
```
- GSAP `ScrollTrigger` + timeline para vincular animaciones a scroll
- Theatre.js `sequence` para secuencias multi-paso

---

## Extensibilidad

Este stack es el **punto de partida por defecto**. Según el proyecto, puedes incorporar:

| Necesidad | Alternativa/Extensión |
|-----------|----------------------|
| SPA compleja | React, Vue, Angular, Svelte |
| SSR/SSG | Next.js, Nuxt, Astro |
| Estilos avanzados | Tailwind CSS, Styled Components, CSS Modules |
| Animaciones adicionales | Lottie, React Spring, Popmotion |
| Viz masiva (millones pts) | Deck.gl (WebGL), PixiJS (WebGL 2D), Regl (shaders custom) |
| Scrollytelling | Scrollama + D3 (narrativas de datos al scroll) |
| Charts React-native | Recharts (+ React Spring para transiciones) |
| Animación cinematográfica | Motion Canvas (explainers programáticos) |
| Estado global | Zustand, Pinia, Redux Toolkit |
| Testing | Vitest, Playwright, Cypress |
| Bundler | Vite (preferido), Webpack, Turbopack |

---

## Estructura de Proyecto Recomendada

```
src/
├── components/     # Componentes reutilizables
├── layouts/        # Estructuras de página
├── pages/          # Vistas/rutas principales
├── styles/         # SCSS global + variables Bootstrap custom
├── charts/         # Configuraciones ECharts + temas
├── viz/            # Visualizaciones D3 custom + bindings animados
├── animations/     # Timelines GSAP, secuencias Theatre.js
├── motion/         # Componentes Framer Motion (wrappers animados)
├── types/          # Interfaces y tipos compartidos
├── utils/          # Helpers, interpoladores, funciones puras
└── assets/         # Imágenes, fuentes, iconos
```
