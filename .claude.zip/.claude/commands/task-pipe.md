Ejecuta en secuencia `/sort-tasks` y luego `/parallelize-tasks`.

## Pasos

1. Ejecuta el comando `/sort-tasks`: analiza `dev/tasks/todo/` y genera `.claude/doc/sorted_tasks.md`.
2. Solo si el paso anterior terminó sin errores (sin dependencias circulares), ejecuta `/parallelize-tasks`: lee `sorted_tasks.md` y genera `.claude/doc/parallel_tasks.md`.
3. Si `/sort-tasks` reporta un error (ej: ciclo de dependencias), detente y muestra el error al usuario sin ejecutar `/parallelize-tasks`.

## Restricciones

- Ejecuta los pasos en orden estricto, nunca en paralelo.
- No modifiques archivos de tareas, solo orquesta los dos comandos.
