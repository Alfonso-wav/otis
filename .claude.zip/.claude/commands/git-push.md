Commitea los cambios de forma descriptiva y pushea a la rama `main` en el remoto `origin`.

## Pasos

1. Ejecuta `git status` para ver el estado actual (archivos sin trackear, cambios staged/unstaged).
2. Identifica el último push con `git log origin/main..HEAD` para saber qué commits ya existen localmente sin pushear.
3. Lee las tasks completadas en `dev/tasks/done/` y compáralas con los mensajes de commits ya existentes desde el último push. Las tasks que aún no estén reflejadas en ningún commit son las que deben mencionarse.
4. Si hay cambios sin commitear (staged o unstaged) o archivos nuevos:
   - Añade todos los archivos relevantes con `git add -A`.
   - Analiza el `git diff --staged` para entender los cambios concretos.
   - Genera un mensaje de commit descriptivo que:
     - Tenga una primera línea concisa en inglés (max 72 chars) resumiendo el cambio principal.
     - Si hay tasks completadas relevantes, incluya en el cuerpo del commit una sección `Tasks completed:` listando los nombres de las tasks de `dev/tasks/done/` que se reflejan en estos cambios.
     - Si los cambios no corresponden a ninguna task, describe los cambios basándote solo en el diff.
   - Crea el commit.
5. Si la rama actual NO es `main`, haz checkout a `main` y merge de la rama actual.
6. Ejecuta `git push origin main`.
7. Muestra el resultado final al usuario.

## Restricciones

- NO uses `--force` ni `--no-verify`.
- Si hay conflictos de merge, informa al usuario y no fuerces nada.
- Si no hay cambios pendientes, solo haz push de los commits locales que no estén en el remoto.
- Excluye archivos sensibles (.env, credentials, secrets) del add — avisa si detectas alguno.
