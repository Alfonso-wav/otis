Ejecuta las tareas pendientes en el orden definido en `.claude/doc/sorted_tasks.md`.

## Pasos

1. Lee `.claude/doc/sorted_tasks.md` y extrae la sección **Secuencia de ejecución** (lista de IDs ordenados).

2. Para cada ID en orden:
   a. Busca el archivo correspondiente en `dev/tasks/todo/`. Si no existe (ya fue movido a `done/` o no se encuentra), informa al usuario y pasa a la siguiente.
   b. Ejecuta `/do-task {ID}` para esa tarea.
   c. Espera a que `/do-task` termine completamente (incluyendo tests, verificación y git-push) antes de continuar con la siguiente.

3. Si una tarea falla o queda bloqueada, detente y consulta al usuario antes de continuar con las siguientes.

4. Al terminar todas, muestra un resumen: tareas completadas, tareas saltadas y tareas fallidas.



## Restricciones

- Respeta estrictamente el orden de la secuencia. Las dependencias entre tareas lo requieren.
- No ejecutes tareas en paralelo.
- No saltes una tarea fallida sin confirmación del usuario.
