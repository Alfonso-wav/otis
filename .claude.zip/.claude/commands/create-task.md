Analiza la petición del usuario y crea una tarea de desarrollo estructurada.

## Entrada

$ARGUMENTS — descripción de la tarea que el usuario quiere implementar.

## Pasos

1. Lee la descripción del usuario y determina:
   - Qué funcionalidad o cambio se pide.
   - Qué capas del proyecto están involucradas (Core, Shell, APP).
   - Si hay dependencias externas nuevas.

2. Si la descripción es ambigua o le falta contexto, pregunta antes de continuar. No asumas.

3. Explora el código existente del proyecto para entender el estado actual y evitar duplicaciones.

4. Genera un ID corto para la tarea con formato `NNNN-slug` (e.g., `0001-add-user-auth`). Para asignar el número, revisa los archivos existentes en `dev/tasks/todo/` y `dev/tasks/done/` y usa el siguiente número disponible.

5. Crea el archivo `dev/tasks/todo/{ID}.md` usando la plantilla de `.claude/templates/task.md`. Rellena todos los campos `{placeholder}` con la información concreta de la tarea.

6. Muestra al usuario la ruta del archivo creado y un resumen de la tarea.

7. Espera confirmación del usuario antes de implementar.

8. Una vez confirmado, implementa siguiendo el plan. Marca cada paso como completado. Al terminar, mueve el archivo de `dev/tasks/todo/` a `dev/tasks/done/`.



## Restricciones

- No implementes nada sin confirmación explícita del usuario.
- Respeta la dirección de dependencias: APP -> Shell -> Core. Core no importa nada del proyecto.
- Funciones puras en Core, efectos secundarios solo en Shell.
- Si la tarea es demasiado grande, propón dividirla en subtareas (cada una con su propio archivo en `dev/tasks/todo/`). 
- Si se crea más de una tarea, ejecuta el comando /task-pipe al final de todo el proceso
