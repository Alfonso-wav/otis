Ejecuta las tareas pendientes siguiendo los lotes definidos en `.claude/doc/parallel_tasks.md`.

## Pasos

1. Lee `.claude/doc/parallel_tasks.md` y extrae los lotes con sus IDs.

2. Procesa los lotes en orden secuencial (Lote 1 antes que Lote 2, etc.):

   a. Para cada lote, identifica las tareas que siguen en `dev/tasks/todo/`. Salta las que ya estén en `done/`.

   b. Si el lote tiene **una sola tarea**, ejecútala con `/do-task {ID}`.

   c. Si el lote tiene **varias tareas**, lánzalas en paralelo usando el tool Agent (una por tarea) con el prompt de `/do-task {ID}` para cada una. Espera a que todas terminen antes de pasar al siguiente lote.

3. Si una tarea falla o queda bloqueada, detente y consulta al usuario antes de continuar con el siguiente lote.

4. Al terminar todos los lotes, muestra un resumen: tareas completadas, tareas saltadas y tareas fallidas.

## Restricciones

- Respeta el orden de los lotes. Las dependencias entre lotes lo requieren.
- Dentro de un mismo lote, las tareas SÍ pueden ejecutarse en paralelo.
- No saltes una tarea fallida sin confirmación del usuario.
- Respeta la arquitectura Core / Shell / APP y la dirección de dependencias.
- Funciones puras en Core, efectos secundarios solo en Shell.
