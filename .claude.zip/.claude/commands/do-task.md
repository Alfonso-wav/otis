Ejecuta una tarea pendiente del directorio `dev/tasks/todo/`.

## Entrada

$ARGUMENTS — (opcional) ID o slug de la tarea a ejecutar. Si no se proporciona, lista las tareas disponibles y pregunta cuál ejecutar.

## Pasos

1. Lee los archivos en `dev/tasks/todo/`. Si el usuario indicó un ID/slug, busca ese archivo. Si no, muestra la lista y pregunta cuál ejecutar.

2. Lee el archivo de la tarea seleccionada. Extrae:
   - Plan de implementación (los pasos numerados).
   - Archivos a crear/modificar.
   - Capas afectadas.
   - Criterios de aceptación.

3. Explora el código existente del proyecto para entender el estado actual y evitar conflictos.

4. No pidas confirmación al usuario antes de empezar a implementar.

5. Ejecuta el plan paso a paso:
   - Sigue el orden definido en "Plan de implementación".
   - Después de completar cada paso, marca el checkbox o indica progreso al usuario.
   - Si un paso es ambiguo, pregunta antes de continuar.

6. Una vez implementados todos los pasos, ejecuta los tests definidos en la tarea (`go test ./...`).

7. Verifica los criterios de aceptación uno por uno. Reporta cuáles pasan y cuáles no.

8. Si todo pasa, cambia el campo **Estado** de `todo` a `done` en el archivo y muévelo de `dev/tasks/todo/` a `dev/tasks/done/`.

9. Muestra un resumen final: qué se hizo, qué archivos se crearon/modificaron y resultado de los tests.

10. Si todo se ejecutó correctamente, ejecuta el comando `/git-push` para commitear y pushear los cambios.

## Restricciones

- No implementes nada sin confirmación explícita del usuario.
- Respeta la arquitectura Core / Shell / APP y la dirección de dependencias.
- Funciones puras en Core, efectos secundarios solo en Shell.
- Si un paso falla o hay un bloqueo, para y consulta al usuario.
- No modifiques archivos fuera del alcance definido en la tarea sin avisar.
