Analiza las tareas pendientes en `dev/tasks/todo/` y genera un plan de ejecución ordenado en `.claude/doc/sorted_tasks.md`.

## Pasos

1. Lee todos los archivos `.md` en `dev/tasks/todo/`.
2. De cada archivo extrae: **ID**, **Estado**, **Depende de** (puede no existir = sin dependencias), y el título (línea 1, `# ...`).
3. Construye el grafo de dependencias y ordénalas topológicamente:
   - Tareas sin dependencias van primero.
   - Si dos tareas están al mismo nivel, ordena por ID numérico ascendente.
   - Si hay dependencias circulares, repórtalo al usuario y no generes el archivo.
4. Escribe `.claude/doc/sorted_tasks.md` con este formato exacto:

```markdown
# Tareas ordenadas

Generado: {fecha YYYY-MM-DD}

| Orden | ID | Titulo | Depende de |
|-------|----|--------|------------|
| 1 | 0003-frontend-typescript-vite | Migrar frontend a TypeScript + Vite | — |
| 2 | ... | ... | 0003 |

## Secuencia de ejecución

- 0003-frontend-typescript-vite
- 0004-frontend-bootstrap-scss
- ...
```

5. Confirma al usuario cuántas tareas se ordenaron y el resultado.

## Restricciones

- La sección "Secuencia de ejecución" es una lista plana de IDs en orden. Es la que consumirá `/do-sorted-tasks`.
- Si una tarea depende de otra que no existe en `dev/tasks/todo/`, asume que ya fue completada (no bloquea).
- No modifiques los archivos de tareas, solo lee.
