Analiza todo el repositorio y elimina código, archivos y dependencias que no se utilicen.

1. **Dependencias Go no utilizadas**: ejecuta `go mod tidy` para limpiar `go.mod` y `go.sum`.
2. **Imports no utilizados**: revisa todos los archivos `.go` buscando imports sin usar. Elimínalos.
3. **Funciones, tipos y variables exportados no utilizados**: busca símbolos exportados (`func`, `type`, `var`, `const`) que no se referencien en ningún otro lugar del proyecto. Confirma antes de eliminar cada uno.
4. **Funciones y variables privadas no utilizadas**: busca símbolos no exportados que no se usen en su propio paquete. Elimínalos directamente.
5. **Archivos vacíos o sin contenido útil**: detecta archivos `.go` que solo tengan `package X` sin ningún símbolo. Elimínalos.
6. **Archivos no-Go huérfanos**: detecta archivos de configuración, scripts o assets que no se referencien desde el código ni desde `go.mod`/`go.sum`/`Makefile`/`wails.json`. Lista los candidatos y pregunta antes de eliminar.
7. **Dependencias frontend** (si existe `frontend/`): ejecuta el equivalente de limpieza del frontend (ej: eliminar imports no usados en `.ts`/`.tsx`/`.js`).

## Validación

8. Después de cada ronda de limpieza, ejecuta `/test` para verificar que nada se ha roto.
9. Si un test falla tras una eliminación, revierte ese cambio concreto y continúa con el resto.
10. Al terminar, muestra un resumen de todo lo eliminado.

## Restricciones

- No elimines archivos de configuración del proyecto (`wails.json`, `go.mod`, `.claude/`, `docs/`, `dev/`).
- No elimines tests (`_test.go`) aunque parezcan huérfanos — pueden testear comportamiento indirectamente.
- Si `$ARGUMENTS` contiene `--dry-run`, solo reporta qué se eliminaría sin hacer cambios.
