Crea un nuevo comando en `.claude/commands/` siguiendo estas reglas:

## Entrada

- **Nombre**: $ARGUMENTS (sin extensión, se guardará como `$ARGUMENTS.md`)
- Pregunta al usuario qué debe hacer el comando si no queda claro del nombre.

## Reglas de creación

1. **Un comando = una responsabilidad**. Si el usuario pide algo que son dos cosas distintas, crea dos comandos.
2. **Contexto mínimo necesario**: incluye solo las instrucciones que yo (Claude) necesito para ejecutar la tarea. No repitas lo que ya está en CLAUDE.md — asume que siempre lo tengo cargado.
3. **Usa `$ARGUMENTS`** para parametrizar entrada del usuario cuando tenga sentido.
4. **Respeta la arquitectura Core / Shell / APP**: si el comando genera código, indica en qué capa debe vivir.
5. **Formato del comando**:
   - Empieza con un verbo imperativo (Crea, Genera, Ejecuta, Analiza, Refactoriza...).
   - Sé directo: sin explicaciones de por qué, solo el qué y el cómo.
   - Si hay pasos, númeralos.
   - Si hay restricciones, ponlas como lista con guión.
6. **Sin over-engineering**: si el comando se puede expresar en 5 líneas, no uses 20.
7. **Go + funcional**: cualquier código generado sigue el estilo funcional de CLAUDE.md (funciones puras en core, efectos en shell, wiring en app).

## Proceso

1. Lee el nombre del comando y el contexto del usuario.
2. Determina si necesitas preguntar algo antes de crear.
3. Escribe el archivo `.claude/commands/{nombre}.md` con el contenido del comando.
4. Confirma al usuario con una línea: qué hace y cómo se invoca (`/{nombre} [args]`).
