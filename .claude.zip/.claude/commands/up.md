Levanta la aplicación Wails en modo desarrollo.

1. Ejecuta `wails dev` en la raíz del proyecto.
2. Si el comando falla, lee el error y propón una solución antes de reintentar.
- No uses `go run main.go` — esta app usa Wails y necesita el entorno de desarrollo completo (`wails dev`) para servir el frontend embebido y el bridge JS.
