Analiza el repositorio completo en busca de cambios pendientes y aplica las actualizaciones necesarias.

## Pasos

1. Ejecuta `git status` para identificar archivos modificados, nuevos o eliminados.
2. Ejecuta `git diff` para revisar el contenido de los cambios.
3. Para cada cambio detectado, determina si requiere actualizaciones en otras partes del código:
   - **Cambios en `core/`**: verifica que los tipos y funciones modificados se usen correctamente en `shell/` y `app/`.
   - **Cambios en `shell/`**: verifica que las interfaces que implementa sigan siendo compatibles con lo que espera `core/` o `app/`.
   - **Cambios en `app/`**: verifica que el wiring refleje los tipos y firmas actuales de `core/` y `shell/`.
   - **Cambios en `go.mod`**: ejecuta `go mod tidy` si hay dependencias desactualizadas.
   - **Cambios en bindings/frontend**: regenera bindings de Wails si las structs o métodos expuestos cambiaron.
4. Aplica las correcciones necesarias (firmas, imports, tipos, bindings).
5. Ejecuta `go build ./...` para verificar que todo compila.
6. Ejecuta `go vet ./...` para detectar problemas estáticos.
7. Si hay tests, ejecuta `go test ./...` y reporta fallos.
8. Resume los cambios aplicados en una lista concisa.
9. Guarda esa lista en y la va actualizando en docs/patch/ en forma de nota de parche en formato .md

## Restricciones

- No modifiques lógica de negocio en `core/` salvo que haya errores de compilación directos.
- No agregues código nuevo que no sea estrictamente necesario para resolver incompatibilidades.
- Si un cambio es ambiguo o requiere decisión de diseño, pregunta antes de actuar.
