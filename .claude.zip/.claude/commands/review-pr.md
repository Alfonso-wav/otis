Analiza una pull request de GitHub, detecta conflictos potenciales con `main` y genera una tarea de merge en `dev/tasks/todo/`.

## Entrada

$ARGUMENTS — número o URL de la PR a revisar. Si no se proporciona, lista las PRs abiertas con `gh pr list` y pregunta cuál analizar.

## Pasos

1. Obtén la PR:
   - Si se proporcionó número/URL: `gh pr view {número} --json title,body,headRefName,baseRefName,files,commits`
   - Si no: `gh pr list` → muestra la lista → pregunta cuál analizar.

2. Analiza la PR:
   - Rama origen y destino.
   - Archivos modificados (`gh pr diff {número}`).
   - Descripción y commits incluidos.

3. Detecta conflictos potenciales:
   - Ejecuta `git fetch origin` y compara la rama de la PR con `main` (`git diff main...{rama}`).
   - Identifica archivos que han cambiado en ambas ramas desde el punto de divergencia.
   - Clasifica cada conflicto como: **automático** (git puede resolverlo) o **manual** (requiere intervención).

4. Determina el ID de la tarea: revisa `dev/tasks/todo/` y `dev/tasks/done/` para asignar el siguiente número disponible con formato `NNNN-merge-{slug-rama}`.

5. Crea el archivo `dev/tasks/todo/{ID}.md` siguiendo la plantilla `docs/templates/task.md` con:
   - **Descripción**: qué hace la PR y por qué se mergea.
   - **Capas afectadas**: según los archivos tocados (Core / Shell / APP).
   - **Archivos a crear/modificar**: lista completa de archivos de la PR con su acción.
   - **Plan de implementación**: pasos ordenados para mergear sin conflictos:
     1. Actualizar `main` local.
     2. Resolver cada conflicto manual identificado (uno por paso, con instrucción concreta).
     3. Ejecutar tests.
     4. Hacer el merge o aprobar la PR.
   - **Criterios de aceptación**: tests pasan, sin conflictos pendientes, PR mergeada.
   - **Notas**: lista de conflictos detectados y su tipo (automático/manual).

6. Muestra al usuario la ruta del archivo creado y un resumen: rama, archivos cambiados, conflictos detectados.

## Restricciones

- No mergees nada automáticamente. El plan es para ejecutarse luego con `/do-task`.
- Si no hay conflictos, indícalo explícitamente en las notas y simplifica el plan.
- Si la PR tiene más de 20 archivos modificados, agrupa los conflictos por directorio/capa.
- Respeta la arquitectura Core / Shell / APP al clasificar los archivos afectados.
