Ejecuta todos los tests del proyecto y reporta el resultado.

1. Lee el archivo docs/dependencies.md y tenlo en cuenta para los tests
2. Ejecuta `go test ./...` desde la raíz del proyecto.
3. Si todos los tests pasan, confirma con un resumen breve (paquetes testeados, tests pasados).
4. Si algún test falla:
   - Muestra el nombre del test y el error.
   - Lee el código del test y la función que testea.
   - Propón un fix concreto (sin aplicarlo salvo que el usuario lo pida).
5. Si el usuario pasa argumentos (`$ARGUMENTS`), añádelos al comando: `go test ./... $ARGUMENTS` (ejemplo: `-v`, `-run TestNombre`, `-count=1`, `-race`).
