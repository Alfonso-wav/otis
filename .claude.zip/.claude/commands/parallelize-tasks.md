Analiza las tareas ordenadas en `.claude/doc/sorted_tasks.md` y genera `.claude/doc/parallel_tasks.md` agrupando en lotes las tareas que pueden ejecutarse en paralelo sin conflictos.

## Pasos

1. Lee `.claude/doc/sorted_tasks.md` y extrae la tabla de tareas con sus dependencias.
2. Para cada tarea pendiente (que exista en `dev/tasks/todo/`), lee el archivo completo y extrae:
   - **Depende de**: IDs de tareas previas requeridas.
   - **Capas afectadas**: Core, Shell, APP.
   - **Archivos a crear/modificar**: lista concreta de archivos tocados.
3. Agrupa las tareas en **lotes paralelos** (batches). Dos tareas pueden ir en el mismo lote si y solo si:
   - Ninguna depende de la otra (ni directa ni transitivamente).
   - No modifican los mismos archivos ni directorios comunes.
   - No afectan las mismas capas de forma conflictiva (ej: dos tareas que modifican `wails.json` NO van juntas).
4. Ordena los lotes: el lote 1 no tiene dependencias pendientes, el lote 2 depende solo de tareas del lote 1, etc.
5. Escribe `.claude/doc/parallel_tasks.md` con este formato exacto:

```markdown
# Tareas paralelizables

Generado: {fecha YYYY-MM-DD}

## Lote 1 (sin dependencias)

| ID | Titulo | Archivos afectados |
|----|--------|--------------------|
| 0003-... | ... | frontend/package.json, ... |

## Lote 2 (depende de: Lote 1)

| ID | Titulo | Archivos afectados |
|----|--------|--------------------|
| 0004-... | ... | ... |
| 0006-... | ... | ... |

## Resumen

- Total tareas: N
- Lotes: M
- Tareas paralelizables: X de N (las que comparten lote con otra)
```

6. Confirma al usuario: cuántos lotes, cuántas tareas por lote, y si detectó conflictos que impidieron paralelizar.

## Restricciones

- Solo lee archivos, no modifica tareas ni sorted_tasks.
- Si una tarea depende de otra que no está en `dev/tasks/todo/`, asúmela completada (no bloquea).
- Sé conservador: ante la duda de conflicto, NO paralelices. Es preferible un lote extra a una ejecución corrupta.
- Los archivos afectados deben extraerse del plan de la tarea, no inventarse.
