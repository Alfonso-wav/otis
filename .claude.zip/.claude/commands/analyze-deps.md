Analiza la estructura completa del proyecto y genera/actualiza el archivo `./docs/dependencies.md` con un reporte exhaustivo.

## Pasos

1. Lee `go.mod` para extraer: nombre del módulo, versión de Go, dependencias directas e indirectas con sus versiones.
2. Ejecuta `go list -m all` para obtener el árbol completo de dependencias resueltas.
3. Ejecuta `go list -m -u all` para detectar dependencias con actualizaciones disponibles.
4. Analiza la estructura de directorios del proyecto (carpetas, archivos `.go`, organización por capas core/shell/app).
5. Para cada paquete interno, identifica qué imports externos usa (con `go list -f '{{.ImportPath}}: {{join .Imports ", "}}' ./...`).
6. Escribe/actualiza `./docs/dependencies.md` con las siguientes secciones:

## Formato del reporte

```markdown
# Dependencias y Estructura del Proyecto

> Última actualización: {fecha actual}

## Módulo
- Nombre: ...
- Versión de Go: ...

## Estructura del proyecto
{árbol de directorios con descripción breve de cada carpeta/archivo .go}

## Dependencias directas
| Paquete | Versión actual | Última versión | Estado |
|---------|---------------|----------------|--------|

## Dependencias indirectas
| Paquete | Versión |
|---------|---------|

## Mapa de imports por paquete interno
{cada paquete interno y los imports externos que usa}

## Resumen
- Total dependencias directas: N
- Total dependencias indirectas: N
- Dependencias con actualización disponible: N
```

## Restricciones

- Si `./docs/` no existe, créalo.
- Sobrescribe `./docs/dependencies.md` completamente en cada ejecución.
- No modifiques ningún archivo del proyecto, solo el reporte.
- Si algún comando de Go falla, reporta el error en el reporte en lugar de abortar.
