# CLAUDE.md — Development Principles

---

## Lenguaje y paradigma

- **Go** como lenguaje principal.
- **Programación funcional** como estilo base: funciones puras, sin efectos secundarios en la lógica de negocio, datos inmutables (value types, no punteros a estado compartido), sin estado global.
- Go no es un lenguaje funcional puro, pero se puede escribir de forma funcional: usar structs como valores, evitar mutación innecesaria, preferir retornar nuevos valores en lugar de modificar los existentes.

---

## Arquitectura en tres capas: Core / Shell / APP

### Core — la lógica pura

- **Qué hace**: contiene toda la lógica de negocio y de dominio.
- **Regla de oro**: **sin efectos secundarios**. Las funciones de Core solo transforman datos de entrada en datos de salida.
- **Sin dependencias externas**: Core no importa paquetes de base de datos, HTTP, archivos, ni nada que toque el mundo exterior.
- **Inmutabilidad**: trabaja con value types (`struct` por valor, no por puntero) cuando sea posible.
- **Testeable de forma trivial**: al ser puras, las funciones de Core se testean con input/output sin mocks ni setup.

```
core/
  domain.go      // tipos de dominio (structs, enums, constantes)
  logic.go       // funciones puras de transformación y validación
  logic_test.go  // tests unitarios simples
```

Ejemplo de lo que SÍ va en Core:
```go
func CalculateTotal(items []Item) float64 { ... }
func Validate(order Order) error { ... }
func ApplyDiscount(price float64, pct float64) float64 { ... }
```

### Shell — los adaptadores al mundo exterior

- **Qué hace**: todo lo que tiene efectos secundarios o depende de conexiones externas.
- Aquí viven: clientes HTTP, repositorios de base de datos, lectores de archivos, productores/consumidores de mensajes (Kafka, etc.), etc.
- **Depende de Core** (usa sus tipos), pero Core **nunca** depende de Shell.
- Implementa interfaces definidas en Core o en APP para que la dependencia fluya hacia adentro.
- Es la capa variable: cambia cuando cambian las integraciones externas.

```
shell/
  db/
    postgres.go    // implementación concreta del repositorio
  http/
    client.go      // cliente HTTP externo
  storage/
    s3.go          // almacenamiento de archivos
```

### APP — el cableado

- **Qué hace**: conecta Core y Shell. Es la capa de arranque e inyección de dependencias.
- Aquí está el `main.go` y la inicialización de la aplicación.
- Lee configuración (env vars, flags, archivos de config).
- Instancia las implementaciones de Shell y las inyecta donde Core las necesita.
- Define los handlers HTTP/gRPC/CLI que orquestan llamadas a Core usando los adaptadores de Shell.
- Es la única capa que "sabe" cómo está montada la aplicación concreta.

```
app/
  main.go        // entry point
  server.go      // setup del servidor HTTP/gRPC
  config.go      // lectura de configuración
  handlers/
    order.go     // handler que usa Core + Shell juntos
```

---

## Flujo de dependencias

```
APP
 ├── importa Core   (para usar la lógica)
 └── importa Shell  (para instanciar adaptadores)

Shell
 └── importa Core   (para usar los tipos de dominio)

Core
 └── no importa nada de este proyecto (solo stdlib si hace falta)
```

La dirección de dependencia es siempre **hacia adentro**: APP → Shell → Core. Core nunca mira hacia afuera.

---

## Convenciones Go

- **Interfaces pequeñas**: define interfaces de 1-3 métodos cerca de donde se usan, no en el paquete que las implementa.
- **Errores explícitos**: siempre `return value, error`. Nunca panic salvo en init de arranque irrecuperable.
- **Nombres claros**: evita abreviaciones crípticas. `userRepository` mejor que `ur`.
- **Sin globals**: no usar variables globales de estado. Pasar dependencias por parámetro o en structs.
- **Structs como configuración**: cuando una función necesita muchos parámetros, agruparlos en un struct.
- **Tests en el mismo paquete**: `_test.go` junto al archivo que testea. Los tests de Core son triviales; los de Shell pueden requerir mocks o DBs de prueba.

---

## Estructura de proyecto tipo

```
project/
  core/          // lógica pura, tipos de dominio
  shell/         // adaptadores externos (db, http, storage...)
  app/           // main, config, handlers, wiring
  go.mod
  go.sum
```

Para proyectos pequeños, `core/` y `shell/` pueden ser paquetes planos. Para proyectos grandes, pueden tener subdirectorios por dominio/feature.

---

## Lo que hay que evitar

- Lógica de negocio en handlers o en Shell.
- Llamadas a base de datos o HTTP dentro de Core.
- Estado global o `init()` con efectos secundarios.
- Herencia o jerarquías de tipos complejas (Go no es OOP).
- Over-engineering: si algo es simple, que se quede simple. La arquitectura sirve al código, no al revés.
