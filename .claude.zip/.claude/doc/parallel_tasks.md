# Tareas paralelizables

Generado: 2026-03-14

## Lote 1 (sin dependencias)

| ID | Titulo | Archivos afectados |
|----|--------|--------------------|
| 0027-battle-log-pokemon-names | Mostrar nombre del Pokémon en cada línea del log de batalla | core/battle.go, core/battle_test.go, app/bindings.go, frontend/src/pages/builds.ts |
| 0027-pokedex-multi-select-filters | Filtros multi-seleccion y toggles independientes en Pokedex | frontend/src/pages/pokedex.ts, frontend/index.html, frontend/src/styles/_components.scss |

## Resumen

- Total tareas: 2
- Lotes: 1
- Tareas paralelizables: 2 de 2 (ambas en el mismo lote)
