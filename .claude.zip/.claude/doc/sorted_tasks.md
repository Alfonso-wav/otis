# Tareas ordenadas

Generado: 2026-03-14

| Orden | ID | Titulo | Depende de |
|-------|----|--------|------------|
| 1 | 0027-battle-log-pokemon-names | Mostrar nombre del Pokémon en cada línea del log de batalla | — |
| 2 | 0027-pokedex-multi-select-filters | Filtros multi-seleccion y toggles independientes en Pokedex | — |

## Secuencia de ejecución

- 0027-battle-log-pokemon-names
- 0027-pokedex-multi-select-filters
